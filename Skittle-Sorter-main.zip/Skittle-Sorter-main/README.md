# Skittle-Sorter

This is the code made with Arduino and C# for my skittle sorter.
